<?php
session_start();
include('MySql.php');
$nome=$_POST['nome'];
$email=$_POST['email'];
$senha=$_POST['senha'];
$datanasc=$_POST['data'];
$sql=MySql::conectar()->prepare("INSERT INTO cliente(nomecliente,emailcliente, senhacliente, datanascliente) VALUES(?,?,?,?)");
$sql->execute(array($nome,$email,$senha,$datanasc));
if($sql->rowCount()==1){
    echo("<script>"."alert('Cadastro efetuado com sucesso!')"."</script>");
    echo("<meta http-equiv='refresh' content='0; url=login.php'>");
}else{
    echo("<script>"."alert('Erro ao realizar o cadastro, revise suas credências.')"."</script>");
    echo("<meta http-equiv='refresh' content='0; url=registro.php'>");
}
?>