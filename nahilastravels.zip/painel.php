
<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Nahila´s Travels</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/album/">

    

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">

<link href="dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }

      .bd-mode-toggle {
        z-index: 1500;
      }

      .bd-mode-toggle .dropdown-menu .active .bi {
        display: block !important;
      }
    </style>

    
  </head>
  <body>
    <svg xmlns="http://www.w3.org/2000/svg" class="d-none">
      <symbol id="check2" viewBox="0 0 16 16">
        <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
      </symbol>
      <symbol id="circle-half" viewBox="0 0 16 16">
        <path d="M8 15A7 7 0 1 0 8 1v14zm0 1A8 8 0 1 1 8 0a8 8 0 0 1 0 16z"/>
      </symbol>
      <symbol id="moon-stars-fill" viewBox="0 0 16 16">
        <path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/>
        <path d="M10.794 3.148a.217.217 0 0 1 .412 0l.387 1.162c.173.518.579.924 1.097 1.097l1.162.387a.217.217 0 0 1 0 .412l-1.162.387a1.734 1.734 0 0 0-1.097 1.097l-.387 1.162a.217.217 0 0 1-.412 0l-.387-1.162A1.734 1.734 0 0 0 9.31 6.593l-1.162-.387a.217.217 0 0 1 0-.412l1.162-.387a1.734 1.734 0 0 0 1.097-1.097l.387-1.162zM13.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.156 1.156 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.156 1.156 0 0 0-.732-.732l-.774-.258a.145.145 0 0 1 0-.274l.774-.258c.346-.115.617-.386.732-.732L13.863.1z"/>
      </symbol>
      <symbol id="sun-fill" viewBox="0 0 16 16">
        <path d="M8 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
      </symbol>
    </svg>
    
<header data-bs-theme="dark">
  <div class="collapse text-bg-dark" id="navbarHeader">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 col-md-7 py-4">
          <h4>Quem somos?</h4>
          <p class="text-body-secondary">Nahila's Travels é uma agência de exposição de viagens dedicada a inspirar e orientar aventureiros a explorarem o Brasil
           de maneira autêntica e personalizada. 
           Nosso foco é criar experiências únicas, promovendo destinos extraordinários 
           e oferecendo uma visão detalhada sobre as melhores formas de aproveitar cada local.
Através de nossa curadoria cuidadosa e expertise, conectamos viajantes a novas culturas, paisagens deslumbrantes e momentos inesquecíveis, 
sempre com um toque pessoal e atenção aos detalhes.</p>
        </div>
        <div class="col-sm-4 offset-md-1 py-4">
          <h4>Para reservar sua passagem entre em contato conosco:</h4>
          <ul class="list-unstyled">
            <li><a href="#" class="text-white">Email: nahilastravels@gmail.com</a></li>
            <li><a href="#" class="text-white">Telefone: 35230045</a></li>
            <li><a href="#" class="text-white">Instagram: nahilastravelsoficial</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="navbar navbar-dark bg-dark shadow-sm">
    <div class="container">
      <a href="#" class="navbar-brand d-flex align-items-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" aria-hidden="true" class="me-2" viewBox="0 0 24 24"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
        <strong>Nahila´s Travels</strong>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </div>
</header>

<main>

  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">Nahila´s Travels</h1>
        <p class="lead text-body-secondary"> Seja você um explorador experiente ou um iniciante em busca de sua primeira grande aventura, Nahila's Travels está aqui para transformar seus sonhos de viagem em realidade.</p>
        <p>
      </div>
    </div>
  </section>

  <div class="album py-5 bg-body-tertiary">
    <div class="container">

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://www.passagenspromo.com.br/blog/wp-content/uploads/2019/10/turismo-em-brasilia-740x415.jpeg">
            <div class="card-body">
              <p class="card-text">Brasília é a capital federal do Brasil e a sede de governo do Distrito Federal.
              A política de planejamento da cidade, como a localização de prédios residenciais em grandes áreas urbanas,
               a construção de enormes avenidas que atravessam a cidade e a sua divisão em setores tem provocado debates
                sobre o estilo de vida nas grandes cidades no século XX.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Brasília</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">R$890,00</button>
                </div>
                <small class="text-body-secondary">Nahila´s Travels</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
         <img src="https://www.passagenspromo.com.br/blog/wp-content/uploads/2019/02/o-que-fazer-em-bh-1.jpg">
            <div class="card-body">
              <p class="card-text">Belo Horizonte é um município brasileiro e a capital do estado de Minas Gerais. Sua população é de 2 315 560 habitantes
              Cercada pela Serra do Curral, que lhe serve de moldura natural e referência histórica,
               foi planejada e construída para ser a capital política e administrativa do estado mineiro sob influência das ideias do positivismo, 
               num momento de forte apelo da ideologia republicana no país.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Belo Horizonte</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">R$ 565,00</button>
                </div>
                <small class="text-body-secondary">Nahila´s Travels</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
            <img src="https://cdn.folhape.com.br/img/pc/1100/1/dn_arquivo/2023/08/turismo-em-fortaleza-ppp-da-beira-mar.jpg">
            <div class="card-body">
              <p class="card-text">Fortaleza é um município brasileiro, capital e a cidade mais populosa do estado do Ceará, situado na região Nordeste do Brasil. 
              Possui, ainda, a terceira região metropolitana mais rica das regiões Norte e Nordeste.
               É importante centro industrial e comercial do Brasil, com o oitavo maior poder de compra municipal da nação. </p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Fortaleza</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">R$ 378,00</button>
                </div>
                <small class="text-body-secondary">Nahila´s Travels</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
           <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTct3q0OSiLtOMT3ULlbtOObh-fPT6LNvo0iQ&s">
            <div class="card-body">
              <p class="card-text">Recife é um município brasileiro, capital do estado de Pernambuco,
               localizado na Região Nordeste do país.Recife é a metrópole mais rica do Norte-Nordeste e sétima do Brasil, 
               articulando, em sua região geográfica intermediária, 71 cidades, que somam um PIB de 135 bilhões de reais.
               Já o município isoladamente detém o décimo terceiro maior PIB do país e o maior PIB per capita entre as capitais nordestinas.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Recife</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">R$ 760,00</button>
                </div>
                <small class="text-body-secondary">Nahila´s Travels</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
           <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEkiaOm7TEYj075FYM01MI8X3lhPRfoB8t2Q&s">
            <div class="card-body">
              <p class="card-text">Porto Alegre é um município brasileiro e a capital do Rio Grande do Sul, estado mais meridional do Brasil.
              Além disso, Porto Alegre é uma das cidades mais arborizadas e alfabetizadas do país, é um polo regional de atração de migrantes em busca de melhores condições de vida, 
              trabalho e estudo e tem uma infraestrutura em vários aspectos superior à das demais capitais do Brasil.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Porto Alegre</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">R$ 410,00</button>
                </div>
                <small class="text-body-secondary">Nahila´s Travels</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
           <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRF1qShe4jJ4s9-OzdzE8AAtZFtJjoj84k6mw&s">
            <div class="card-body">
              <p class="card-text">Rio de Janeiro, simplesmente referido como Rio, é um município brasileiro, capital do estado homônimo, situado no Sudeste do país.
              um dos principais centros econômicos, culturais e financeiros do país, sendo internacionalmente conhecida por diversos ícones culturais e paisagísticos, 
              como o Pão de Açúcar, o morro do Corcovado com a estátua do Cristo Redentor, as praias dos bairros de Copacabana.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Rio de Janeiro</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">R$ 480,00</button>
                </div>
                <small class="text-body-secondary">Nahila´s Travels</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="https://media.gazetadopovo.com.br/2024/03/27200407/00305108-960x540.jpg">
            <div class="card-body">
              <p class="card-text">Curitiba é um município brasileiro, capital do estado do Paraná, localizado a 934 metros de altitude no Primeiro Planalto Paranaense.
              Curitiba tornou-se uma importante parada comercial com a abertura da estrada tropeira entre Sorocaba e Viamão,
               vindo, em 1853, a ser a capital da recém-emancipada Província do Paraná.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Curitiba</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">R$ 590,00</button>
                </div>
                <small class="text-body-secondary">Nahila´s Travels</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
           <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQGG9h6L8ZZvsl_abVL-U95hxzwMle4tbbJA&s">
            <div class="card-body">
              <p class="card-text">Foz do Iguaçu é um município brasileiro localizado na região oeste do estado do Paraná. 
               É o terceiro destino de turistas estrangeiros no país e o primeiro da região sul.
                Conhecida internacionalmente pelas Cataratas do Iguaçu, uma das vencedoras do concurso que escolheu as 7 Maravilhas da Natureza</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Foz do Iguaçu</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">R$ 600,00</button>
                </div>
                <small class="text-body-secondary">Nahila´s Travels</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
           <img src="https://opopular.com.br/image/policy:1.3092004:1702466661/image.jpg">
            <div class="card-body">
              <p class="card-text">Goiás é uma das 27 unidades federativas do Brasil. Situa-se na Região Centro-Oeste do país, no Planalto Central brasileiro. 
              A história de Goiás remonta ao início do século XVIII, com a chegada dos bandeirantes vindos de São Paulo, atraídos pela descoberta de minas de ouro.
               Bartolomeu Bueno da Silva, o Anhanguera, liderou a primeira bandeira com a intenção de se fixar no território, que saiu de São Paulo</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">Goiás</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">R$ 570,00</button>
                </div>
                <small class="text-body-secondary">Nahila´s Travels</small>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</main>

<footer class="text-body-secondary py-5">
  <div class="container">
    <p class="float-end mb-1">
      <a href="#">Voltar ao topo</a>
    </p>
    <p class="mb-1">Nosso site está em constante atualização, 
    qualquer eventual dúvida acesse nossas redes sociais e fique por dentro de todas as novidades e destinos incríveis que temos para você!</p>
    <p class="mb-0"> <a href="/"></a> <a href=></a></p>
  </div>
</footer>
<script src="dist/js/bootstrap.bundle.min.js"></script>

    </body>
</html>