<?php
session_start();
include('MySql.php');
$email=$_POST['email'];
$senha=$_POST['senha'];
$sql=MySql::conectar()->prepare("SELECT * FROM cliente WHERE emailcliente=? AND senhacliente=?");
$sql->execute(array($email,$senha));
if($sql->rowCount()==1){
  $_SESSION['conectado']="logado";
  echo("<meta http-equiv='refresh' content='1; url=painel.php'>");
  echo("<script>"."alert('Login efetuado com sucesso!')"."</script>");
}else{
  echo("<script>"."alert('Erro ao efetuar o login, tente novamente!')"."</script>");
  echo("<meta http-equiv='refresh' content='1; url=login.php'>");
}
?>